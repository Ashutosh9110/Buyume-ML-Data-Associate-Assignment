# Car recognition > 2023-10-10 8:01pm
https://universe.roboflow.com/test-asvdx/car-recognition-2tsm2

Provided by a Roboflow user
License: Public Domain

